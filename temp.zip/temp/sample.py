
from __future__ import annotations

class Vector3:
	pass

class BasePrimitive:
	pass

class Sphere:
	pass

class BoundingBox:
	pass

class Camera:
	pass

class RayResult:
	pass

class Ray:
	pass

class MaterialReflectionData:
	pass

class Material:
	pass

class DieletricMaterial(Material):
	pass

class LambertianMaterial(Material):
	pass

class MetalMaterial(Material):
	pass

class RendererData:
	pass

class DefaultRenderPipeline:
	pass

class DefaultRaytracer:
	pass

if __name__ == '__main__':
	pass
